package comd.debu.relationship;

public class Department {

}
