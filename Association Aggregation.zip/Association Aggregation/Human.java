package comd.debu.relationship;

// Composition
public class Human {
	

		   //without human a heart can not exist
		   private final Human heart;

		   public Human () {
		      heart = new Human();
		   }
		}

