package comd.debu.relationship;

public class Teacher {

}
