package comd.debu.relationship;

public class Heart {

}
